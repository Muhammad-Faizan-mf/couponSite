<?php $__env->startSection('content'); ?>
<div class="card mt-5">
  <h2 class="card-header">Show Blog</h2>
  <div class="card-body">
    
    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
        <a class="btn btn-primary btn-sm" href="<?php echo e(route('blogs.index')); ?>"><i class="fa fa-arrow-left"></i> Back</a>
    </div>

    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Name:</strong> <br/>
                <?php echo e($blog->name); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 mt-2">
            <div class="form-group">
                <strong>Details:</strong> <br/>
                <?php echo e($blog->detail); ?>


            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 mt-2">
            <div class="form-group">
                <strong>Category:</strong> <br/>
                <?php echo e($blog->category->name); ?>


            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Image:</strong><br/>
                <img src="/images/blogs/<?php echo e($blog->image); ?>" width="500px">
            </div>
        </div>
    </div>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.default', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/muhammadfaizan/Desktop/GIAIC/couponSite/couponSiteApplication/resources/views/blog/show.blade.php ENDPATH**/ ?>