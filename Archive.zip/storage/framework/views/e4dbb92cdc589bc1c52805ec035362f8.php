<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Categories</h1>
    <div class="pull-right">

                <a class="btn btn-success" href="<?php echo e(route('category.create')); ?>"> Add</a>

            </div>
    <div class="row">
        <table class="table table-bordered data-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($cat->id); ?></td>
                        <td><?php echo e($cat->name); ?></td>
                        <td>
                            <form action="<?php echo e(route('category.destroy',$cat->id)); ?>" method="POST">

                                <a class="btn btn-info btn-sm" href="<?php echo e(route('category.show',$cat->id)); ?>"><i class="fa-solid fa-list"></i> Show</a>

                                <a class="btn btn-primary btn-sm" href="<?php echo e(route('category.edit',$cat->id)); ?>"><i class="fa-solid fa-pen-to-square"></i> Edit</a>

                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                                <button type="submit" class="btn btn-danger btn-sm"><i class="fa-solid fa-trash"></i> Delete</button>
                            </form>
                        </td>                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="3">There are no cats.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.default', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/muhammadfaizan/Desktop/GIAIC/couponSite/couponSiteApplication/resources/views/admin/category.blade.php ENDPATH**/ ?>