<?php $__env->startSection('content'); ?>
<div class="row">

    <div class="col-lg-12 margin-tb">

        <div class="pull-left">

            <h2> Show Category</h2>

        </div>

        <div class="pull-right">

            

        </div>

    </div>

</div>



<div class="row">

    <div class="col-xs-12 col-sm-12 col-md-12 p-10 m-10">

        <div class="form-group">

            <strong>Name:</strong>
            <?php echo e($category->name); ?>


        </div>

    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.default', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/muhammadfaizan/Desktop/GIAIC/couponSite/couponSiteApplication/resources/views/category/show.blade.php ENDPATH**/ ?>